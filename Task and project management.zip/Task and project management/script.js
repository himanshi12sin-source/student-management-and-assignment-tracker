
const $ = (id) => document.getElementById(id);

const STORAGE_KEY = "taskflow_project_management_v1";

const initialData = {
    projects: [
        {
            id: "p1",
            name: "Website Development",
            description: "Build and launch a responsive company website.",
            color: "#6c63ff"
        },
        {
            id: "p2",
            name: "Mobile App UI",
            description: "Design a clean and user-friendly mobile application.",
            color: "#2196f3"
        }
    ],
    tasks: [
        {
            id: "t1",
            title: "Create homepage layout",
            description: "Build the homepage wireframe and layout.",
            projectId: "p1",
            priority: "High",
            due: "",
            status: "progress"
        },
        {
            id: "t2",
            title: "Design login page",
            description: "Prepare the login page design.",
            projectId: "p2",
            priority: "Medium",
            due: "",
            status: "todo"
        },
        {
            id: "t3",
            title: "Setup project structure",
            description: "Create folders and initial files.",
            projectId: "p1",
            priority: "Low",
            due: "",
            status: "completed"
        },
        {
            id: "t4",
            title: "Review app requirements",
            description: "Review all requirements for the application.",
            projectId: "p2",
            priority: "High",
            due: "",
            status: "todo"
        }
    ]
};

let data;

try {
    const saved = localStorage.getItem(STORAGE_KEY);
    data = saved ? JSON.parse(saved) : structuredClone(initialData);

    if (!data || !Array.isArray(data.projects) || !Array.isArray(data.tasks)) {
        data = structuredClone(initialData);
    }
} catch {
    data = structuredClone(initialData);
}

let currentPage = "dashboard";
let currentStatusFilter = "all";

function saveData() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function escapeHTML(value) {
    return String(value ?? "").replace(/[&<>"']/g, (char) => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    }[char]));
}

function projectName(id) {
    return data.projects.find(p => p.id === id)?.name || "Deleted Project";
}

function getProgress(projectId) {
    const tasks = data.tasks.filter(t => t.projectId === projectId);
    if (!tasks.length) return 0;

    const completed = tasks.filter(t => t.status === "completed").length;
    return Math.round((completed / tasks.length) * 100);
}

function statusLabel(status) {
    return {
        todo: "To Do",
        progress: "In Progress",
        completed: "Completed"
    }[status] || "To Do";
}

function showEmpty(message) {
    return `<div class="empty">${escapeHTML(message)}</div>`;
}

function showToast(message) {
    const toast = $("toast");
    toast.textContent = message;
    toast.classList.add("show");

    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.classList.remove("show"), 2500);
}

// ---------------- DASHBOARD ----------------

function renderDashboard() {
    const total = data.tasks.length;
    const progress = data.tasks.filter(t => t.status === "progress").length;
    const completed = data.tasks.filter(t => t.status === "completed").length;

    $("total-projects").textContent = data.projects.length;
    $("total-tasks").textContent = total;
    $("progress-tasks").textContent = progress;
    $("completed-tasks").textContent = completed;

    const recentTasks = data.tasks.slice(0, 5);

    $("dashboard-task-list").innerHTML = recentTasks.length
        ? recentTasks.map(task => `
            <div class="task-row">
                <input class="task-check" type="checkbox"
                    data-complete="${task.id}"
                    ${task.status === "completed" ? "checked" : ""}>
                <div class="task-info">
                    <strong>${escapeHTML(task.title)}</strong>
                    <small>${escapeHTML(projectName(task.projectId))} · ${escapeHTML(statusLabel(task.status))}</small>
                </div>
                <span class="priority ${escapeHTML(task.priority)}">${escapeHTML(task.priority)}</span>
            </div>
        `).join("")
        : showEmpty("No tasks yet. Create your first task!");

    $("dashboard-project-list").innerHTML = data.projects.length
        ? data.projects.slice(0, 5).map(project => {
            const percent = getProgress(project.id);
            const count = data.tasks.filter(t => t.projectId === project.id).length;

            return `
                <div class="project-progress">
                    <div class="project-progress-top">
                        <span>${escapeHTML(project.name)}</span>
                        <span>${percent}%</span>
                    </div>
                    <div class="progress-track">
                        <div class="progress-fill"
                            style="width:${percent}%;background:${project.color}"></div>
                    </div>
                    <small>${count} tasks</small>
                </div>
            `;
        }).join("")
        : showEmpty("No projects created yet.");
}

// ---------------- PROJECTS ----------------

function renderProjects() {
    $("projects-grid").innerHTML = data.projects.length
        ? data.projects.map(project => {
            const tasks = data.tasks.filter(t => t.projectId === project.id);
            const percent = getProgress(project.id);

            return `
                <div class="project-card">
                    <div class="project-card-top">
                        <span class="project-dot" style="background:${project.color}"></span>
                        <div class="card-actions">
                            <button class="icon-btn" data-edit-project="${project.id}" title="Edit">✎</button>
                            <button class="icon-btn" data-delete-project="${project.id}" title="Delete">✕</button>
                        </div>
                    </div>
                    <h3>${escapeHTML(project.name)}</h3>
                    <p>${escapeHTML(project.description || "No description added.")}</p>
                    <div class="progress-track">
                        <div class="progress-fill" style="width:${percent}%;background:${project.color}"></div>
                    </div>
                    <div class="project-card-bottom">
                        <span>${tasks.length} tasks</span>
                        <strong>${percent}% complete</strong>
                    </div>
                </div>
            `;
        }).join("")
        : showEmpty("No projects yet. Create your first project!");
}

// ---------------- TASKS ----------------

function renderTasks() {
    const search = $("search-input").value.toLowerCase().trim();
    const priorityFilter = $("filter-priority").value;

    let filtered = data.tasks.filter(task => {
        const matchesSearch =
            task.title.toLowerCase().includes(search) ||
            task.description.toLowerCase().includes(search) ||
            projectName(task.projectId).toLowerCase().includes(search);

        const matchesPriority =
            priorityFilter === "all" || task.priority === priorityFilter;

        const matchesStatus =
            currentStatusFilter === "all" || task.status === currentStatusFilter;

        return matchesSearch && matchesPriority && matchesStatus;
    });

    $("task-table-body").innerHTML = filtered.length
        ? filtered.map(task => `
            <tr>
                <td><strong>${escapeHTML(task.title)}</strong></td>
                <td>${escapeHTML(projectName(task.projectId))}</td>
                <td><span class="priority ${escapeHTML(task.priority)}">${escapeHTML(task.priority)}</span></td>
                <td>${escapeHTML(task.due || "No deadline")}</td>
                <td>
                    <select class="status-select" data-status="${task.id}">
                        <option value="todo" ${task.status === "todo" ? "selected" : ""}>To Do</option>
                        <option value="progress" ${task.status === "progress" ? "selected" : ""}>In Progress</option>
                        <option value="completed" ${task.status === "completed" ? "selected" : ""}>Completed</option>
                    </select>
                </td>
                <td>
                    <button class="icon-btn" data-edit-task="${task.id}" title="Edit">✎</button>
                    <button class="icon-btn" data-delete-task="${task.id}" title="Delete">✕</button>
                </td>
            </tr>
        `).join("")
        : `<tr><td colspan="6">${showEmpty("No matching tasks found.")}</td></tr>`;
}

function renderAll() {
    renderDashboard();
    renderProjects();
    renderTasks();
}

// ---------------- NAVIGATION ----------------

function showPage(page, statusFilter = "all") {
    currentPage = page;
    currentStatusFilter = statusFilter;

    document.querySelectorAll(".page").forEach(section => {
        section.classList.add("hidden");
    });

    const target = $(`${page}-page`);
    if (target) target.classList.remove("hidden");

    document.querySelectorAll(".nav-btn").forEach(button => {
        button.classList.remove("active");
    });

    const activeButton = document.querySelector(
        `.nav-btn[data-page="${page}"]`
    );

    if (activeButton) activeButton.classList.add("active");

    const titles = {
        dashboard: "Dashboard",
        projects: "Projects",
        tasks: statusFilter === "all" ? "All Tasks" : statusLabel(statusFilter)
    };

    $("page-title").textContent = titles[page] || "Dashboard";
    renderAll();
}

document.querySelectorAll(".nav-btn[data-page]").forEach(button => {
    button.addEventListener("click", () => {
        showPage(button.dataset.page);
    });
});

document.querySelectorAll(".nav-btn[data-filter]").forEach(button => {
    button.addEventListener("click", () => {
        showPage("tasks", button.dataset.filter);
    });
});

document.querySelectorAll("[data-goto]").forEach(button => {
    button.addEventListener("click", () => showPage(button.dataset.goto));
});

// ---------------- MODALS ----------------

function openModal(id) {
    $(id).classList.remove("hidden");
}

function closeModal(id) {
    $(id).classList.add("hidden");
}

document.querySelectorAll("[data-close]").forEach(button => {
    button.addEventListener("click", () => closeModal(button.dataset.close));
});

document.querySelectorAll(".modal-overlay").forEach(overlay => {
    overlay.addEventListener("click", event => {
        if (event.target === overlay) closeModal(overlay.id);
    });
});

document.addEventListener("keydown", event => {
    if (event.key === "Escape") {
        document.querySelectorAll(".modal-overlay").forEach(modal => {
            modal.classList.add("hidden");
        });
    }
});

// ---------------- PROJECT FORM ----------------

function openProjectForm(projectId = null) {
    $("project-form").reset();
    $("project-id").value = "";

    if (projectId) {
        const project = data.projects.find(p => p.id === projectId);
        if (!project) return;

        $("project-modal-title").textContent = "Edit Project";
        $("project-id").value = project.id;
        $("project-name").value = project.name;
        $("project-description").value = project.description;
        $("project-color").value = project.color;
    } else {
        $("project-modal-title").textContent = "Create Project";
    }

    openModal("project-modal");
}

$("add-project-top").addEventListener("click", () => openProjectForm());
$("add-project-page").addEventListener("click", () => openProjectForm());

$("project-form").addEventListener("submit", event => {
    event.preventDefault();

    const id = $("project-id").value;
    const project = {
        id: id || uid(),
        name: $("project-name").value.trim(),
        description: $("project-description").value.trim(),
        color: $("project-color").value
    };

    if (!project.name) return;

    if (id) {
        const index = data.projects.findIndex(p => p.id === id);
        if (index !== -1) data.projects[index] = project;
        showToast("Project updated successfully!");
    } else {
        data.projects.unshift(project);
        showToast("Project created successfully!");
    }

    saveData();
    closeModal("project-modal");
    renderAll();
});

// ---------------- TASK FORM ----------------

function populateProjectDropdown(selectedId = "") {
    $("task-project").innerHTML = data.projects.map(project => `
        <option value="${project.id}" ${project.id === selectedId ? "selected" : ""}>
            ${escapeHTML(project.name)}
        </option>
    `).join("");

    if (!data.projects.length) {
        $("task-project").innerHTML = `<option value="">Create a project first</option>`;
    }
}

function openTaskForm(taskId = null) {
    if (!data.projects.length) {
        showToast("Please create a project first.");
        openProjectForm();
        return;
    }

    $("task-form").reset();
    $("task-id").value = "";
    populateProjectDropdown();

    if (taskId) {
        const task = data.tasks.find(t => t.id === taskId);
        if (!task) return;

        $("task-modal-title").textContent = "Edit Task";
        $("task-id").value = task.id;
        $("task-title").value = task.title;
        $("task-description").value = task.description;
        $("task-project").value = task.projectId;
        $("task-priority").value = task.priority;
        $("task-due").value = task.due;
        $("task-status").value = task.status;
    } else {
        $("task-modal-title").textContent = "Create Task";
    }

    openModal("task-modal");
}

$("add-task-top").addEventListener("click", () => openTaskForm());
$("add-task-page").addEventListener("click", () => openTaskForm());

$("task-form").addEventListener("submit", event => {
    event.preventDefault();

    const id = $("task-id").value;
    const task = {
        id: id || uid(),
        title: $("task-title").value.trim(),
        description: $("task-description").value.trim(),
        projectId: $("task-project").value,
        priority: $("task-priority").value,
        due: $("task-due").value,
        status: $("task-status").value
    };

    if (!task.title || !task.projectId) return;

    if (id) {
        const index = data.tasks.findIndex(t => t.id === id);
        if (index !== -1) data.tasks[index] = task;
        showToast("Task updated successfully!");
    } else {
        data.tasks.unshift(task);
        showToast("Task created successfully!");
    }

    saveData();
    closeModal("task-modal");
    renderAll();
});

// ---------------- EDIT & DELETE ----------------

document.addEventListener("click", event => {
    const editProject = event.target.closest("[data-edit-project]");
    const deleteProject = event.target.closest("[data-delete-project]");
    const editTask = event.target.closest("[data-edit-task]");
    const deleteTask = event.target.closest("[data-delete-task]");

    if (editProject) {
        openProjectForm(editProject.dataset.editProject);
    }

    if (deleteProject) {
        const id = deleteProject.dataset.deleteProject;
        const project = data.projects.find(p => p.id === id);
        if (!project) return;

        const confirmed = confirm(
            `Delete "${project.name}" and all its tasks?`
        );

        if (confirmed) {
            data.projects = data.projects.filter(p => p.id !== id);
            data.tasks = data.tasks.filter(t => t.projectId !== id);
            saveData();
            renderAll();
            showToast("Project deleted.");
        }
    }

    if (editTask) {
        openTaskForm(editTask.dataset.editTask);
    }

    if (deleteTask) {
        const id = deleteTask.dataset.deleteTask;
        if (confirm("Are you sure you want to delete this task?")) {
            data.tasks = data.tasks.filter(t => t.id !== id);
            saveData();
            renderAll();
            showToast("Task deleted.");
        }
    }
});

// ---------------- STATUS CHANGES ----------------

document.addEventListener("change", event => {
    const statusId = event.target.dataset.status;
    const completeId = event.target.dataset.complete;

    if (statusId) {
        const task = data.tasks.find(t => t.id === statusId);
        if (!task) return;

        task.status = event.target.value;
        saveData();
        renderAll();
        showToast("Task status updated.");
    }

    if (completeId) {
        const task = data.tasks.find(t => t.id === completeId);
        if (!task) return;

        task.status = event.target.checked ? "completed" : "todo";
        saveData();
        renderAll();
        showToast("Task status updated.");
    }
});

// ---------------- SEARCH & FILTER ----------------

$("search-input").addEventListener("input", renderTasks);
$("filter-priority").addEventListener("change", renderTasks);

// ---------------- INITIALIZATION ----------------

renderAll();
showPage("dashboard");
